<?php
interface IParte2{
    public function Agregar();
    public static function Traer();
    public function ActivarVelocidadWarp();
    public function Existe();
}
?>