<?php
require_once(__DIR__ . "/IParte2.php");
class Ovni implements IParte2{
    public $tipo;
    public $velocidad;
    public $planetaOrigen;
    public $pathFoto;

    public function __construct($nuevoTipo = "",$nuevaVelocidad = 0, $nuevoOrigen = "" , $nuevoPath = "")
    {
        $this->tipo = $nuevoTipo;
        $this->velocidad = $nuevaVelocidad;
        $this->planetaOrigen = $nuevoOrigen;
        $this->pathFoto = $nuevoPath;
    }

    public function ToJson(){
        return json_encode($this);
    }

    public function Agregar(){
        $retorno = false;
        try{
            $objetoPDO = new PDO("mysql:host=localhost;dbname=aliens_bd;charset=utf8", "root", "");
        
            $consulta = $objetoPDO->prepare("INSERT INTO ovnis(tipo, velocidad, planetaOrigen, pathFoto)" .
            "VALUES (:tipo,:velocidad,:planetaOrigen,:pathFoto)");
            $consulta->bindValue(':tipo', $this->tipo, PDO::PARAM_STR);
            $consulta->bindValue(':velocidad', $this->velocidad, PDO::PARAM_INT);
            $consulta->bindValue(':planetaOrigen', $this->planetaOrigen, PDO::PARAM_STR);
            $consulta->bindValue(':pathFoto', $this->pathFoto, PDO::PARAM_STR);
            $retorno = $consulta->execute();
            $objetoPDO = null;
        } catch(PDOException $error){
            return false;
        }
        return $retorno;
    }

    public static function Traer(){
        $objetoPDO;
        $OvnisArray = array();
        try{
            $objetoPDO = new PDO("mysql:host=localhost;dbname=aliens_bd;charset=utf8", "root", "");
        } catch(PDOException $error){
            return $error;
        }
        $consulta = $objetoPDO->prepare("SELECT * FROM ovnis");
        $consulta->execute();
        $OvnisArray = $consulta->fetchAll(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, "Ovni");
        return $OvnisArray;
    }
    
    public function ActivarVelocidadWarp(){
        return $this->velocidad * 10.45;
    }

    public function Existe(){
        $retorno = false;
        try{
            $objetoPDO = new PDO("mysql:host=localhost;dbname=aliens_bd;charset=utf8", "root", "");
            
            $consulta = $objetoPDO->prepare("SELECT * FROM ovnis WHERE tipo = :tipo AND velocidad = :velocidad AND planetaOrigen = :planetaOrigen AND pathFoto = :pathFoto");
            $consulta->bindValue(':tipo', $this->tipo, PDO::PARAM_STR);
            $consulta->bindValue(':velocidad', $this->velocidad, PDO::PARAM_INT);
            $consulta->bindValue(':planetaOrigen', $this->planetaOrigen, PDO::PARAM_STR);
            $consulta->bindValue(':pathFoto', $this->pathFoto, PDO::PARAM_STR);
            $consulta->execute();
            $resultado = $consulta->fetch();
            $retorno = !(empty($resultado));
            $objetoPDO = null;
        } catch(PDOException $error){
            return false;
        }
        return $retorno;
    }

}
?>